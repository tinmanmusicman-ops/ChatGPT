@echo off
REM Gmail -> Sheets Poller Runner
SET PY=python
%PY% poll_gmail_to_sheet.py
echo.
pause
