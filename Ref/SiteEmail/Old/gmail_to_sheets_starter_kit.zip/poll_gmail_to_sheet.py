#!/usr/bin/env python3
"""
Gmail → Google Sheets poller (high-detail logging)
- Polls UNREAD emails whose Subject contains PHONE_MARKER (e.g., "672-7323")
- Appends [timestamp, content] to the first sheet of SPREADSHEET_NAME
- Uses IMAP for Gmail, Service Account for Sheets
- Remember processed message UIDs to avoid duplicates

Setup:
  pip install -r requirements.txt
  Put your GCP service account JSON as service_account.json (and share the sheet with it).
  Copy .env.example to .env and fill in values.

Run:
  python poll_gmail_to_sheet.py
"""

import imaplib
import email
from email.header import decode_header
import time
import json
from datetime import datetime
import logging
import logging.handlers
import os
import re
import sys
import socket
from zoneinfo import ZoneInfo

from dotenv import load_dotenv
import gspread
from google.oauth2.service_account import Credentials

# =============== Logging Setup (maximum detail) ===============
LOG_DIR = os.path.abspath(os.getenv("LOG_DIR", "./logs"))
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "poller.log")

root_logger = logging.getLogger()
root_logger.setLevel(logging.DEBUG)  # Highest verbosity

# Stream handler (console)
ch = logging.StreamHandler(sys.stdout)
ch.setLevel(logging.DEBUG)
ch.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s - %(message)s"))
root_logger.addHandler(ch)

# Rotating file handler
fh = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
fh.setLevel(logging.DEBUG)
fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(filename)s:%(lineno)d - %(message)s"))
root_logger.addHandler(fh)

logger = logging.getLogger("gmail_to_sheets_poller")

# ========================= Config & helpers =========================
load_dotenv()

GMAIL_USER = os.getenv("GMAIL_USER")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD")
PHONE_MARKER = os.getenv("PHONE_MARKER", "672-7323")
SPREADSHEET_NAME = os.getenv("SPREADSHEET_NAME", "LGBTQ")
WORKSHEET_INDEX = int(os.getenv("WORKSHEET_INDEX", "1"))  # 1-based like "sheet1"; default first
STATE_FILE = os.getenv("STATE_FILE", "processed_uids.json")
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "30"))
IMAP_HOST = os.getenv("IMAP_HOST", "imap.gmail.com")
IMAP_FOLDER = os.getenv("IMAP_FOLDER", "INBOX")
TIMEZONE = os.getenv("TIMEZONE", "America/Los_Angeles")
MARK_SEEN = os.getenv("MARK_SEEN", "false").lower() in {"1","true","yes"}

if not GMAIL_USER:
    logger.error("GMAIL_USER is not set. Check your .env")
if not GMAIL_APP_PASSWORD:
    logger.warning("GMAIL_APP_PASSWORD is empty; IMAP login will fail. Set it in your .env")

# Google Sheets auth
SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

def authorize_sheets():
    logger.debug("Authorizing Google Sheets with service_account.json ...")
    creds = Credentials.from_service_account_file("service_account.json", scopes=SCOPES)
    client = gspread.authorize(creds)
    logger.debug("Opening spreadsheet: %s", SPREADSHEET_NAME)
    sh = client.open(SPREADSHEET_NAME)
    ws = sh.get_worksheet(WORKSHEET_INDEX - 1)  # 0-based index in gspread
    if ws is None:
        raise RuntimeError(f"Worksheet index {WORKSHEET_INDEX} not found.")
    logger.info("Connected to Google Sheet '%s' (worksheet index %d)", SPREADSHEET_NAME, WORKSHEET_INDEX)
    return ws

def load_processed_uids():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                logger.debug("Loaded %d processed UIDs from %s", len(data), STATE_FILE)
                return set(data)
        except Exception as e:
            logger.exception("Failed to load %s: %s", STATE_FILE, e)
            return set()
    logger.debug("No state file found; starting fresh.")
    return set()

def save_processed_uids(uids):
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(sorted(list(uids)), f)
        logger.debug("Saved %d processed UIDs to %s", len(uids), STATE_FILE)
    except Exception as e:
        logger.exception("Failed to save %s: %s", STATE_FILE, e)

def decode_mime_header(value):
    if not value:
        return ""
    decoded_parts = decode_header(value)
    out = ""
    for text, enc in decoded_parts:
        try:
            if isinstance(text, bytes):
                out += text.decode(enc or "utf-8", errors="replace")
            else:
                out += text
        except Exception:
            logger.exception("Error decoding header part with enc=%s", enc)
    return out

def extract_text_content(msg):
    """Prefer text/plain; fallback to stripped text/html."""
    def strip_html(html):
        # Compact whitespace after stripping
        text = re.sub(r"<[^>]+>", " ", html)
        return re.sub(r"\s+", " ", text).strip()

    if msg.is_multipart():
        for part in msg.walk():
            ctype = (part.get_content_type() or "").lower()
            disp = str(part.get("Content-Disposition") or "")
            if ctype == "text/plain" and "attachment" not in disp.lower():
                try:
                    payload = part.get_payload(decode=True)
                    return payload.decode(part.get_content_charset() or "utf-8", errors="replace").strip()
                except Exception:
                    logger.exception("Failed to decode text/plain part")
        # Fallback to HTML
        for part in msg.walk():
            ctype = (part.get_content_type() or "").lower()
            disp = str(part.get("Content-Disposition") or "")
            if ctype == "text/html" and "attachment" not in disp.lower():
                try:
                    payload = part.get_payload(decode=True)
                    html = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
                    return strip_html(html)
                except Exception:
                    logger.exception("Failed to decode text/html part")
    else:
        ctype = (msg.get_content_type() or "").lower()
        body = msg.get_payload(decode=True)
        if body is None:
            return ""
        try:
            text = body.decode(msg.get_content_charset() or "utf-8", errors="replace")
        except Exception:
            logger.exception("Failed to decode singlepart body; falling back to utf-8")
            text = body.decode("utf-8", errors="replace")
        if ctype == "text/html":
            return strip_html(text)
        return text.strip()
    return ""

def append_to_sheet(ws, timestamp_str, content):
    try:
        ws.append_row([timestamp_str, content], value_input_option="RAW")
        logger.info("Appended to sheet: [%s, %s...]", timestamp_str, (content[:60] + "…") if len(content) > 60 else content)
    except Exception as e:
        logger.exception("Failed to append row to sheet: %s", e)
        raise

def connect_imap():
    logger.debug("Connecting to IMAP host: %s", IMAP_HOST)
    m = imaplib.IMAP4_SSL(IMAP_HOST)
    logger.debug("Logging in as %s", GMAIL_USER)
    m.login(GMAIL_USER, GMAIL_APP_PASSWORD)
    typ, _ = m.select(IMAP_FOLDER)
    if typ != "OK":
        raise RuntimeError(f"Unable to select folder {IMAP_FOLDER}")
    logger.info("Connected to %s, folder %s", IMAP_HOST, IMAP_FOLDER)
    return m

def search_matching_uids(m):
    # Gmail's SEARCH SUBJECT is substring, case-insensitive
    logger.debug('Searching for UNSEEN with SUBJECT containing: "%s"', PHONE_MARKER)
    status, data = m.search(None, 'UNSEEN', 'SUBJECT', f'"{PHONE_MARKER}"')
    if status != "OK":
        logger.warning("IMAP search returned status=%s; data=%s", status, data)
        return []
    ids = data[0].split()
    uids = [i.decode("utf-8") for i in ids if i]
    logger.debug("Search results: %d UIDs", len(uids))
    return uids

def fetch_message(m, uid):
    logger.debug("Fetching message UID=%s", uid)
    status, data = m.uid("fetch", uid, "(RFC822)")
    if status != "OK" or not data or data[0] is None:
        logger.warning("Failed to fetch UID=%s: status=%s data=%s", uid, status, data)
        return None
    raw = data[0][1]
    try:
        return email.message_from_bytes(raw)
    except Exception:
        logger.exception("Failed to parse RFC822 for UID=%s", uid)
        return None

def mark_seen(m, uid):
    try:
        m.uid('store', uid, '+FLAGS', '(\\Seen)')
        logger.debug("Marked UID=%s as Seen", uid)
    except Exception:
        logger.exception("Failed to mark UID=%s as Seen", uid)

def main():
    logger.info("=== Gmail poller starting (TZ=%s, poll=%ss) ===", TIMEZONE, POLL_SECONDS)
    try:
        ws = authorize_sheets()
    except Exception:
        logger.exception("Google Sheets authorization/open failed. Exiting.")
        sys.exit(2)

    processed = load_processed_uids()

    while True:
        try:
            m = connect_imap()
            uids = search_matching_uids(m)
            for uid in uids:
                if uid in processed:
                    logger.debug("UID %s already processed; skipping", uid)
                    continue

                msg = fetch_message(m, uid)
                if not msg:
                    continue

                subj = decode_mime_header(msg.get("Subject"))
                logger.debug("UID %s subject: %s", uid, subj)

                # Double-check marker presence
                if PHONE_MARKER not in subj:
                    logger.debug("UID %s subject missing marker; skipping", uid)
                    continue

                content = extract_text_content(msg).strip()
                if not content:
                    content = "(no body text)"

                ts = datetime.now(ZoneInfo(TIMEZONE)).isoformat(timespec="seconds")
                append_to_sheet(ws, ts, content)

                processed.add(uid)
                save_processed_uids(processed)

                if MARK_SEEN:
                    mark_seen(m, uid)

            try:
                m.close()
            except Exception:
                logger.debug("IMAP close raised; ignoring", exc_info=True)
            try:
                m.logout()
            except Exception:
                logger.debug("IMAP logout raised; ignoring", exc_info=True)

        except (imaplib.IMAP4.error, socket.timeout, socket.gaierror) as e:
            logger.exception("IMAP-related error: %s", e)
        except Exception as e:
            logger.exception("Unexpected top-level error: %s", e)

        logger.debug("Sleeping for %s seconds", POLL_SECONDS)
        time.sleep(POLL_SECONDS)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Shutting down on CTRL+C")
